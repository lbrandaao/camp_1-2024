//
//  campiosApp.swift
//  campios
//
//  Created by Camp - 2024 on 23/04/24.
//

import SwiftUI

@main
struct campiosApp: App {
    var body: some Scene {
        WindowGroup {
            LoginView()
        }
    }
}
